from django.apps import AppConfig


class CricketappConfig(AppConfig):
    name = 'cricketapp'
