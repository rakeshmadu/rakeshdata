from django.apps import AppConfig


class MoviesAppConfig(AppConfig):
    name = 'movies_app'
